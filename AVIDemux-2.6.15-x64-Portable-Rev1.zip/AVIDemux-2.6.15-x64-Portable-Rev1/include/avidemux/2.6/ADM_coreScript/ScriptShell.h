#ifndef ADM_SHELL_H
#define ADM_SHELL_H

#include "IScriptEngine.h"

bool ADM_startShell(IScriptEngine *engine);

#endif