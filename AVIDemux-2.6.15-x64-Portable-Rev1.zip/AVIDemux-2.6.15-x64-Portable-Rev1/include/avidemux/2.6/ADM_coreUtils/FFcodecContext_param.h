#ifndef FFCODECCONTEXT_PARAM_H
#define FFCODECCONTEXT_PARAM_H

#include "ADM_coreUtils6_export.h"

extern ADM_COREUTILS6_EXPORT const ADM_paramList FFcodecContext_param[];

#endif