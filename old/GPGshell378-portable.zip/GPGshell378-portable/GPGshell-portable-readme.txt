Launch 'GPGtray.exe' to get started.

http://www.portablefreeware.com/index.php?id=2068
http://www.portablefreeware.com/forums/viewtopic.php?f=4&t=8118
