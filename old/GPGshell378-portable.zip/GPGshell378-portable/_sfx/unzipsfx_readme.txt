
This version of unzipsfx.exe has been compiled with CHEAP_SFX_AUTORUN defined,
it also contains a custom icon and a changed prompt when extracting a SFX with
"autorun" enabled. This is not an official Info-ZIP release.

