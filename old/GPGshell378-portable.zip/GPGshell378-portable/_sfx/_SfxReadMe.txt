
Symmetric encrypted SFX-archives (using Info-ZIP)

This folder contains the necessary files to enable the possibility of building
symmetrically encrypted SFX-archives. GPGshell will build a self-extracting
ZIP-archive, which contains the encrypted file, the gpg.exe from your system,
the GPL (for GnuPG) and a batch-file. That batch-file will be executed by the
SFX-engine to decrypt the file for the recipient.

A "SFX"-checkbox will appear in the key-selection dialog when encrypting
files. It will be enabled after checking the "Symmetrical"-checkbox.

- When this folder also contains a file named gpg_sfx.exe, which is a renamed
  gpg.exe (maybe compressed), it will be included in the SFX-archive instead
  of the one in your system's PATH. Please keep in mind that GnuPG <= v1.4.7
  is licensed under GPL v2 and GnuPG >= v1.4.8 is licensed under GPL v3.
- An additional text-file containing the MD5/SHA1 sums of the encrypted file
  will be created beside the SFX-archive. This file should not be sent to-
  gether with the SFX-archive, but it may be used to check the file-integrity
  via phone, because the recipient will also see the MD5/SHA1 sums while ex-
  tracting the archive.

Please visit http://www.info-zip.org and http://www.gnu.org/licenses/gpl.html
to get more information about the Info-ZIP project and the GNU General Public
License.
