Possible batch-input from GPGkeys:

   [%1]    [%2]    [%3]   [%4]   [%5]   ...
1.                                             <- no key selection
2. LongID  ShortID Name_1 Name_2 Name_3 ...    <- single key selection
3. _multi_ LongID  LongID LongID LongID ...    <- multiple key selection

"_multi_" is just a marker and should be removed with a single "SHIFT".

Additional or modified batches should be placed in a _batches folder below
the GPGshell-HomeDir, to make sure that they will not be overwritten with
the next install of GPGshell.
