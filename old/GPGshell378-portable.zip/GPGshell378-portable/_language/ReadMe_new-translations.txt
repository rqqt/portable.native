If you want to add a translation for your language:

1. Please ask me early enough if someone is already working on it.
2. Message-boxes and window-captions cannot be translated.
3. You may have to use a lot of abbreviations to get your strings
   into the buttons and labels.
4. There are no plans to change anything in GPGshell regarding 2.
   and 3.
5. You have to provide a valid mail-address for the user's questions
   and suggestions.
6. You will get new strings to translate for each new release of
   GPGshell.
7. Don't make any changes in the *.lng files, except on the right
   side of "   =".
8. "x#_" strings MUST be translated, but without the "x#_"-part.
9. Compress the *.lng files (ARJ, ZIP, ...), before you send them to
   me via e-mail, otherwise it is possible that your language specific
   characters will be converted or removed by the servers.

You make the translation for the users who speak your language, not
for me, so please don't make your translation dependent on getting
new features or general changes.
