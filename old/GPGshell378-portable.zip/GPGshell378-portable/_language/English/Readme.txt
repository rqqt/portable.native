
The english translation is just a dummy to force the hard-coded english
strings in multi-user environments, when the default language has been
set to a non-english language while installing GPGshell.
