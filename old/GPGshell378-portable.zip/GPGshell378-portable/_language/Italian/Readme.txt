=====================================================================

GPGshell Translation

Language     = Italian
Translators  = TJL73 & Carlo Luciano Bianco
Contact      = <tjl73@x-privat.org>
Website      = <http://tjl73.altervista.org/>
Newsgroup    = <it.comp.sicurezza.pgp>
Newsgroup    = <it.comp.sicurezza.crittografia>
Region       = Italia

=====================================================================

Tradotto da TJL73 <tjl73@x-privat.org>
Mille grazie a Carlo Luciano Bianco per i controlli effettuati.
Per qualsiasi domanda o segnalazione di errori relativi a questa
traduzione, fare riferimento all'indirizzo e-mail qui sopra oppure
postare nel newsgroup <it.comp.sicurezza.crittografia> oppure
<it.comp.sicurezza.pgp>

=====================================================================

Translated by TJL73 <tjl73@x-privat.org>
Many thanks to Carlo Luciano Bianco for checking.
For any question or bug-report about this translation please refer to
the above e-mail address or ask in <it.comp.sicurezza.crittografia>
or <it.comp.sicurezza.pgp> newsgroups.

=====================================================================
