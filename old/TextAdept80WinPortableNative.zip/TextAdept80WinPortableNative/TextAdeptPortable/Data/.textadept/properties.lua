-- IN TEXTADEPT SELECT TEXT AND PRESS CTRL + H FOR DOCUMENTATION

--The whitespace visibility mode.
--buffer.view_ws            = buffer.WS_VISIBLEALWAYS

-- Line Endings
--  buffer.view_eol = true

--The wrapped line visual flag display mode.
buffer.wrap_visual_flags  = buffer.WRAPVISUALFLAG_END

--The wrapped line visual flag drawing mode.
buffer.wrap_visual_flags_location = buffer.WRAPVISUALFLAGLOC_DEFAULT

--Long line wrap mode.
buffer.wrap_mode = buffer.WRAP_WHITESPACE

--Extend the selection to the view’s right margin. The default value is false.
buffer.sel_eol_filled = true

--Color the background of the line that contains the caret a different color. The default value is false.
buffer.caret_line_visible = true

--The time between caret blinks in milliseconds. A value of 0 stops blinking. The default value is 500.
buffer.caret_period = 500

--The caret’s visual style. buffer.CARETSTYLE_LINE.
buffer.caret_style = buffer.CARETSTYLE_LINE

--The line caret’s pixel width in insert mode, either 0, 1, 2, or 3. The default value is 1.
buffer.caret_width = 3