-- IN TEXTADEPT SELECT TEXT AND PRESS CTRL + H FOR DOCUMENTATION

--ui.set_theme('light', {font = 'Inconsolata', fontsize = 14})
--ui.set_theme('light', {font = 'Anonymous Pro', fontsize = 14})
ui.set_theme('light', {font = 'Courier New', fontsize = 14})

--Strip trailing whitespace before saving files. The default value is false.
textadept.editing.STRIP_TRAILING_SPACES = true
